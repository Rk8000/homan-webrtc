(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/rtc_serv.js                                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Peers = new Meteor.Stream('peers');                                    // 1
                                                                       //
Meteor.startup(function () {                                           // 3
  //Audio = new Mongo.Collection("audio");                             //
                                                                       //
  // code to run on server at startup                                  //
  Audio.remove({});                                                    // 7
  //Audio.insert({workerId: "me", state:"disconnected"});              //
});                                                                    //
                                                                       //
Meteor.publish("unconnected", function () {                            // 12
  return Audio.find({ state: "unconnected" });                         // 13
});                                                                    //
                                                                       //
/*Peers.addFilter(function(eventName, args) {                          //
  //var userId = this.userId; //you can get the userId if user is logged in
  //alter and modify args array                                        //
                                                                       //
  console.log("boogyboogybo")                                          //
  return args;                                                         //
});*/                                                                  //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=rtc_serv.js.map
